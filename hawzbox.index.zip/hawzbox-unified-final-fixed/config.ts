
export const APP_CONFIG = {
  appName: "HawzBox",
  appSlogan: "Find Houses in Nigeria",
  logoLetter: "H",
  colors: {
    primary: "#B1EB01",
    background: "#000000",
    card: "#161616",
    border: "#252525",
    surface: "#111111",
    text: "#FFFFFF",
    muted: "#A1A1A1"
  },
  payToView: { enabled: true, amount: 500 },
  payToPost: { enabled: false, amount: 1000 },
  support: { phone: "07032156113", whatsapp: "08169812007", email: "support@hawzbox.com", instagram: "https://instagram.com/hawzbox" },
  houseTypes: ["Self Contain", "Single Room", "1 Bedroom", "2 Bedroom", "3 Bedroom", "Duplex", "Bungalow", "Store"],
  listingTypes: ["For Rent", "For Sale"] as const,
  defaultAmenities: ["Constant Water", "Steady Power", "Security", "Prepaid Meter", "Fenced & Gated", "Parking Space"],
  features: { videoUpload: true, chat: true, comments: true },
}
export const NIGERIA_STATES: Record<string, string[]> = {
  "Rivers State": ["Port Harcourt", "Choba", "Alakahia", "GRA", "Trans-Amadi", "Elelenwo"],
  "Lagos State": ["Ikeja", "Lekki", "Yaba", "Surulere", "VI", "Ikoyi", "Ajah"],
  "Abuja FCT": ["Wuse", "Garki", "Maitama", "Asokoro", "Gwarimpa"],
  "Kano State": ["Kano Municipal", "Fagge", "Dala"],
  "Akwa Ibom State": ["Uyo", "Etim Ekpo", "Ikot Ekpene"],
}
