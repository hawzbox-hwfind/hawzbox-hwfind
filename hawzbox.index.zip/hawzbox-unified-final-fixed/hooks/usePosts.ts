
'use client'
import { useEffect, useState } from 'react'
import { supabase, Post } from '@/lib/supabase'
export function usePosts(){
  const [posts,setPosts]=useState<Post[]>([])
  const [loading,setLoading]=useState(true)
  const fetchPosts=async()=>{
    setLoading(true)
    try{
      const {data, error}=await supabase.from('posts').select('*').order('created_at',{ascending:false}).limit(100)
      if(error) throw error
      if(data && data.length>0) setPosts(data as Post[])
      else throw new Error('empty')
    }catch{
      setPosts([
        {id:'1', title:'Self Contain in Choba', price:350000, area:'Choba', state:'Rivers', address:'Choba PH', housetype:'Self Contain', type:'For Rent', amenities:['Water','Light'], images:['https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800'], owner_id:'1', owner_name:'Verified User', owner_phone:'0703...', owner_whatsapp:'0816...', created_at:new Date().toISOString(), taken:false},
        {id:'2', title:'2 Bedroom in GRA', price:1200000, area:'GRA', state:'Rivers', address:'GRA Phase 2', housetype:'2 Bedroom', type:'For Rent', amenities:['Security'], images:['https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800'], owner_id:'2', owner_name:'John', owner_phone:'0703...', owner_whatsapp:'0816...', created_at:new Date().toISOString(), taken:false},
      ])
    }finally{ setLoading(false) }
  }
  useEffect(()=>{ fetchPosts() },[])
  return {posts, loading, refetch:fetchPosts}
}
