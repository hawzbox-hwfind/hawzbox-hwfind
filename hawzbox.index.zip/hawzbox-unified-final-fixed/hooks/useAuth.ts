
'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
export function useAuth(){
  const [user,setUser]=useState<any>(null)
  const [loading,setLoading]=useState(true)
  useEffect(()=>{
    supabase.auth.getSession().then(({data})=>{ setUser(data.session?.user||null); setLoading(false) })
    const {data:sub}=supabase.auth.onAuthStateChange((_e,sess)=> setUser(sess?.user||null))
    return ()=> sub.subscription.unsubscribe()
  },[])
  return {user, loading, signOut:()=>supabase.auth.signOut()}
}
