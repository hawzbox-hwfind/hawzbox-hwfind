
export async function compressImage(file: File, max=1280, q=0.75): Promise<Blob>{
  return new Promise((res, rej)=>{
    const img=new Image()
    img.onload=()=>{
      const c=document.createElement('canvas')
      let w=img.width, h=img.height
      if(w>max){ h=(max/w)*h; w=max }
      c.width=w; c.height=h
      c.getContext('2d')!.drawImage(img,0,0,w,h)
      c.toBlob(b=>b?res(b):rej('compress failed'),'image/jpeg',q)
    }
    img.onerror=rej
    img.src=URL.createObjectURL(file)
  })
}
