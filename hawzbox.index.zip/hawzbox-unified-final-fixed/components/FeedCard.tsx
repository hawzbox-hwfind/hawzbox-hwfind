
'use client'
import { Post } from '@/lib/supabase'
import { APP_CONFIG } from '@/config'
export default function FeedCard({post, onClick}:{post:Post, onClick:()=>void}){
  return (
    <div onClick={onClick} className="bg-[#161616] border border-[#252525] rounded-[18px] overflow-hidden active:scale-[0.98] transition cursor-pointer">
      <div className="relative h-[170px] bg-zinc-900">
        <img src={post.images?.[0] || 'https://via.placeholder.com/300'} alt={post.title} loading="lazy" className="w-full h-full object-cover" />
        {post.videourl && <div className="absolute top-2.5 right-2.5 bg-black/70 backdrop-blur border border-white/10 px-2 py-1 rounded-full text-[9px] flex items-center gap-1"><span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"/>VIDEO</div>}
        {post.taken && <div className="absolute inset-0 bg-black/60 flex items-center justify-center"><span className="bg-white text-black text-[11px] font-bold px-3 py-1 rounded-full">TAKEN</span></div>}
      </div>
      <div className="p-3.5">
        <h3 className="font-semibold text-[13px] line-clamp-1">{post.title}</h3>
        <div className="flex items-center justify-between mt-2">
          <span className="font-bold text-[13px]" style={{color:APP_CONFIG.colors.primary}}>₦{Number(post.price).toLocaleString()}</span>
          <span className="text-[11px] text-zinc-500">{post.area}</span>
        </div>
      </div>
    </div>
  )
}
