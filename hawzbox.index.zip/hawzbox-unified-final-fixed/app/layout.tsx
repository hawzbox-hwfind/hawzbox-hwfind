
import './globals.css'
export const metadata = { title: 'HawzBox - Find Houses in Nigeria', description: 'Professional LIVE house rental' }
export default function RootLayout({children}:{children:React.ReactNode}){
  return (
    <html lang="en">
      <head>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet"/>
      </head>
      <body className="max-w-[430px] mx-auto bg-black min-h-screen relative">{children}</body>
    </html>
  )
}
