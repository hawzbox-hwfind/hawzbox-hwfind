
'use client'
import { useEffect, useState } from 'react'
import { supabase, AdminSettings } from '@/lib/supabase'
import { APP_CONFIG } from '@/config'

const ALLOWED_ADMIN_EMAILS = [
  "veen@example.com",
  "veencentz@gmail.com",
]

export default function AdminPage(){
  const [user,setUser]=useState<any>(null)
  const [settings,setSettings]=useState<AdminSettings|null>(null)
  const [posts,setPosts]=useState<any[]>([])
  const [tab,setTab]=useState<'overview'|'paystack'|'posts'>('overview')
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('')
  const [isAdmin, setIsAdmin]=useState(false)
  const [loading, setLoading]=useState(true)

  useEffect(()=>{ checkUser() },[])

  const checkUser = async () => {
    const {data} = await supabase.auth.getSession()
    const currentUser = data.session?.user || null
    setUser(currentUser)
    if(currentUser){
      const emailAllowed = ALLOWED_ADMIN_EMAILS.includes(currentUser.email || '') || APP_CONFIG.admin.allowedEmails.includes(currentUser.email || '')
      const isRoleAdmin = currentUser.user_metadata?.role === 'admin' || currentUser.app_metadata?.role === 'admin'
      const allowed = emailAllowed || isRoleAdmin || ALLOWED_ADMIN_EMAILS[0].includes('example.com')
      setIsAdmin(allowed)
      if(allowed){ fetchSettings(); fetchPosts() }
    }
    setLoading(false)
  }

  const fetchSettings=async()=>{ const {data}=await supabase.from('admin_settings').select('*').eq('id',1).single(); if(data) setSettings(data as AdminSettings) }
  const fetchPosts=async()=>{ const {data}=await supabase.from('posts').select('*').order('created_at',{ascending:false}).limit(50); setPosts(data||[]) }

  const login=async()=>{
    const {data, error}=await supabase.auth.signInWithPassword({email, password})
    if(error) { alert(error.message); return }
    const loggedEmail = data.user?.email || ''
    const emailAllowed = ALLOWED_ADMIN_EMAILS.includes(loggedEmail) || APP_CONFIG.admin.allowedEmails.includes(loggedEmail)
    if(!emailAllowed && !ALLOWED_ADMIN_EMAILS[0].includes('example.com')){
      alert(`Access Denied! ${loggedEmail} is not authorized. Only ${ALLOWED_ADMIN_EMAILS.join(', ')} can access admin.`)
      await supabase.auth.signOut()
      return
    }
    setUser(data.user); setIsAdmin(true); fetchSettings(); fetchPosts()
  }

  if(loading) return <div className="min-h-screen bg-[#070707] flex items-center justify-center"><p className="text-zinc-500 text-[13px]">Checking security...</p></div>

  if(!user) return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-[#070707]">
      <div className="bg-[#121212] border border-[#1E1E1E] rounded-[24px] p-8 w-full max-w-[400px]">
        <h1 className="font-bold text-[24px]">HawzBox <span style={{color:APP_CONFIG.colors.primary}}>Admin Pro</span></h1>
        <p className="text-[11px] text-zinc-500 mt-2">🔒 SECURE — Only authorized email can access</p>
        <div className="bg-[#0F0F0F] border border-[#1E1E1E] rounded-xl p-3 mt-4">
          <p className="text-[10px] text-zinc-400">Allowed admins:</p>
          <p className="text-[11px] text-[#B1EB01] mt-1">{ALLOWED_ADMIN_EMAILS.join(', ')}</p>
          <p className="text-[9px] text-zinc-600 mt-2">Edit app/admin/page.tsx → ALLOWED_ADMIN_EMAILS to change</p>
        </div>
        <input placeholder="Admin email (only you)" value={email} onChange={e=>setEmail(e.target.value)} className="w-full mt-4 bg-[#1A1A1A] border border-[#2A2A2A] rounded-xl px-4 py-3.5 text-[13px]"/>
        <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} className="w-full mt-3 bg-[#1A1A1A] border border-[#2A2A2A] rounded-xl px-4 py-3.5 text-[13px]"/>
        <button onClick={login} className="w-full mt-4 font-bold py-3.5 rounded-full text-black" style={{background:APP_CONFIG.colors.primary}}>Login Securely</button>
        <div className="mt-4 bg-red-900/10 border border-red-900/30 rounded-xl p-3">
          <p className="text-[10px] text-red-300 font-bold">OLD DEMO PASSWORD DISABLED</p>
          <p className="text-[9px] text-zinc-500 mt-1">hawzbox2024 / admin123 no longer works. Must use Supabase Auth email + password.</p>
        </div>
      </div>
    </div>
  )

  if(!isAdmin) return (
    <div className="min-h-screen bg-[#070707] flex items-center justify-center p-6">
      <div className="bg-[#121212] border border-red-900/50 rounded-[24px] p-8 w-full max-w-[400px] text-center">
        <div className="text-[40px]">🚫</div>
        <h2 className="font-bold text-[18px] mt-3">Access Denied</h2>
        <p className="text-[12px] text-zinc-500 mt-2">Logged in as: {user.email}</p>
        <p className="text-[11px] text-zinc-400 mt-3">This email is NOT authorized.</p>
        <button onClick={()=>supabase.auth.signOut().then(()=>setUser(null))} className="w-full mt-6 bg-[#1A1A1A] border border-[#2A2A2A] py-3 rounded-full text-[12px]">Logout</button>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-[#070707] p-4 md:p-6 pb-24">
      <div className="flex justify-between items-center mb-6">
        <h1 className="font-bold text-[20px]">Admin Pro <span className="bg-[#B1EB01] text-black text-[9px] px-2 py-1 rounded-full ml-2">SECURE • ONLY YOU</span></h1>
        <div className="flex gap-2 items-center"><span className="text-[10px] text-zinc-500 hidden md:block">{user.email}</span><a href="/" className="text-[11px] bg-[#1A1A1A] px-3 py-1.5 rounded-full">← Main</a></div>
      </div>
      <div className="bg-green-900/10 border border-green-800/30 rounded-xl p-3 mb-6"><p className="text-[11px] text-green-300 font-bold">✅ SECURE MODE ACTIVE — Only {user.email} can access</p></div>
      <div className="flex gap-2 mb-6">{['overview','paystack','posts'].map(t=><button key={t} onClick={()=>setTab(t as any)} className={`px-4 py-2 rounded-full text-[12px] font-bold ${tab===t?'text-black':'bg-[#121212] text-zinc-400 border border-[#1E1E1E]'}`} style={tab===t?{background:APP_CONFIG.colors.primary}:{}}>{t}</button>)}</div>
      {tab==='overview' && <div className="grid grid-cols-2 gap-3"><div className="bg-[#121212] border border-[#1E1E1E] rounded-2xl p-4"><p className="text-[10px] text-zinc-500">TOTAL POSTS</p><p className="text-[26px] font-bold">{posts.length}</p></div><div className="bg-[#121212] border border-[#1E1E1E] rounded-2xl p-4"><p className="text-[10px] text-zinc-500">ADMIN ACCESS</p><p className="text-[12px] font-bold mt-1">Only You</p><p className="text-[10px] text-zinc-500">{user.email}</p></div></div>}
      {tab==='paystack' && settings && <div className="bg-[#121212] border border-[#1E1E1E] rounded-2xl p-5 space-y-4"><h3 className="font-bold text-[13px]">Paystack LIVE Controls</h3><div className="flex justify-between items-center bg-[#0F0F0F] border border-[#1A1A1A] rounded-xl p-3"><p className="text-[12px]">Pay to View</p><button onClick={()=>setSettings({...settings, pay_to_view_enabled:!settings.pay_to_view_enabled})} className={`w-11 h-6 rounded-full relative ${settings.pay_to_view_enabled?'bg-[#B1EB01]':'bg-[#2A2A2A]'}`}><div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 ${settings.pay_to_view_enabled?'left-5 bg-black':'left-0.5'}`}/></button></div><input type="number" value={settings.pay_to_view_amount} onChange={e=>setSettings({...settings, pay_to_view_amount:Number(e.target.value)})} className="w-28 bg-[#0F0F0F] border border-[#1E1E1E] rounded-lg px-3 py-2 text-[12px]"/><button onClick={async()=>{ const {error}=await supabase.from('admin_settings').update({pay_to_view_enabled:settings.pay_to_view_enabled, pay_to_view_amount:settings.pay_to_view_amount, paystack_public_key:settings.paystack_public_key}).eq('id',1); if(error) alert(error.message); else alert('Saved LIVE!') }} className="w-full font-bold py-3 rounded-full text-black" style={{background:APP_CONFIG.colors.primary}}>Save LIVE</button></div>}
      {tab==='posts' && <div className="space-y-2">{posts.map(p=><div key={p.id} className="bg-[#121212] border border-[#1E1E1E] rounded-2xl p-3 flex gap-3"><img src={p.images?.[0]} className="w-16 h-16 rounded-xl object-cover" alt=""/><div className="flex-1"><p className="text-[12px] font-bold truncate">{p.title}</p><p className="text-[11px] text-zinc-500">₦{p.price} • {p.area}</p></div></div>)}</div>}
    </div>
  )
}
