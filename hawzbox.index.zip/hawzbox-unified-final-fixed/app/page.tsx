
'use client'
import { useState } from 'react'
import { usePosts } from '@/hooks/usePosts'
import BottomNav from '@/components/BottomNav'
import FeedCard from '@/components/FeedCard'
import PostComposer from '@/components/PostComposer'
import { APP_CONFIG } from '@/config'
type Tab='feed'|'areas'|'chat'|'profile'|'post'
export default function Home(){
  const {posts, loading, refetch}=usePosts()
  const [tab,setTab]=useState<Tab>('feed')
  const [showPost,setShowPost]=useState(false)
  const [query,setQuery]=useState('')
  const [filter,setFilter]=useState<'All'|'For Rent'|'For Sale'>('All')
  const filtered=posts.filter(p=>{
    const ms=!query||p.title.toLowerCase().includes(query.toLowerCase())||p.area.toLowerCase().includes(query.toLowerCase())
    const mt=filter==='All'||p.type===filter
    return ms&&mt
  })
  return (
    <main className="pb-[100px] min-h-screen bg-black">
      {typeof window!=='undefined' && !process.env.NEXT_PUBLIC_SUPABASE_URL && <div className="bg-[#B1EB01] text-black text-[11px] font-bold p-2.5 text-center">⚙️ Add ENV in Vercel to go LIVE — works in demo mode for now</div>}
      <div className="sticky top-0 z-30 bg-black border-b border-[#111] px-5 py-3 flex items-center justify-between">
        <h1 className="font-extrabold text-[22px] tracking-tight">{APP_CONFIG.appName}<span style={{color:APP_CONFIG.colors.primary}}>Box</span></h1>
        <a href="/admin" className="text-[10px] bg-[#161616] border border-[#252525] px-3 py-1.5 rounded-full">Admin →</a>
      </div>
      <div className="px-5 py-4">
        <div className="flex gap-2">
          <div className="flex-1 bg-[#161616] border border-[#252525] rounded-full flex items-center px-4 h-11">
            <span className="text-zinc-500 mr-2">⌕</span>
            <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search Choba, GRA..." className="bg-transparent outline-none text-[13px] w-full"/>
          </div>
          <button onClick={()=>refetch()} className="w-11 h-11 bg-[#1E1E1E] rounded-full">↻</button>
        </div>
        <div className="flex gap-2 mt-4">
          {['All','For Rent','For Sale'].map(t=>(
            <button key={t} onClick={()=>setFilter(t as any)} className={`px-4 py-2 rounded-full text-[12px] font-bold border ${filter===t?'text-black':'bg-[#1E1E1E] text-zinc-400 border-[#2A2A2A]'}`} style={filter===t?{background:APP_CONFIG.colors.primary, borderColor:APP_CONFIG.colors.primary}:{}}>{t}</button>
          ))}
        </div>
      </div>
      <div className="px-3">
        {loading ? <div className="grid grid-cols-2 gap-3">{[1,2,3,4].map(i=><div key={i} className="bg-[#161616] rounded-[18px] h-[220px] animate-pulse"/>)}</div> : <div className="grid grid-cols-2 gap-3">{filtered.map(p=><FeedCard key={p.id} post={p} onClick={()=>alert('Detail + Paywall wired to admin_settings — will check pay_to_view_enabled')} />)}</div>}
      </div>
      <BottomNav active={tab} onChange={(t)=>{ if(t==='post'){ setShowPost(true); return } setTab(t) }} />
      {showPost && <PostComposer onClose={()=>setShowPost(false)} onPosted={()=>refetch()} />}
    </main>
  )
}
