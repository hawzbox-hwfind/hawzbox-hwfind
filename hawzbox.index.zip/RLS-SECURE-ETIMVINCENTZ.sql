
-- 🔒 SECURE RLS FOR etimvincentz001@gmail.com - ONLY YOU CAN ACCESS ADMIN
-- Run this in Supabase SQL Editor

-- 1. admin_settings - public can read paywall status, ONLY you can write
DROP POLICY IF EXISTS "public all" ON admin_settings;
DROP POLICY IF EXISTS "public read" ON admin_settings;
DROP POLICY IF EXISTS "anon read public settings" ON admin_settings;
DROP POLICY IF EXISTS "public can read paywall status" ON admin_settings;
DROP POLICY IF EXISTS "only admin can update settings" ON admin_settings;
DROP POLICY IF EXISTS "only admin can insert settings" ON admin_settings;

CREATE POLICY "public can read paywall status" ON admin_settings FOR SELECT USING (true);
CREATE POLICY "only admin can update settings" ON admin_settings FOR UPDATE USING (
  auth.jwt() ->> 'email' = 'etimvincentz001@gmail.com'
) WITH CHECK (
  auth.jwt() ->> 'email' = 'etimvincentz001@gmail.com'
);
CREATE POLICY "only admin can insert settings" ON admin_settings FOR INSERT WITH CHECK (
  auth.jwt() ->> 'email' = 'etimvincentz001@gmail.com'
);

-- 2. posts - public read, auth can post, ONLY you can delete
DROP POLICY IF EXISTS "public all" ON posts;
DROP POLICY IF EXISTS "public read posts" ON posts;
DROP POLICY IF EXISTS "authenticated can post" ON posts;
DROP POLICY IF EXISTS "only admin can delete" ON posts;

CREATE POLICY "public read posts" ON posts FOR SELECT USING (true);
CREATE POLICY "authenticated can post" ON posts FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "only admin can delete" ON posts FOR DELETE USING (
  auth.jwt() ->> 'email' = 'etimvincentz001@gmail.com'
);
CREATE POLICY "only admin can update posts" ON posts FOR UPDATE USING (
  auth.jwt() ->> 'email' = 'etimvincentz001@gmail.com'
);

-- 3. payments - anyone can pay, ONLY you can read payments
DROP POLICY IF EXISTS "public all" ON payments;
DROP POLICY IF EXISTS "anyone can pay" ON payments;
DROP POLICY IF EXISTS "only admin can read payments" ON payments;

CREATE POLICY "anyone can pay" ON payments FOR INSERT WITH CHECK (true);
CREATE POLICY "only admin can read payments" ON payments FOR SELECT USING (
  auth.jwt() ->> 'email' = 'etimvincentz001@gmail.com'
);

-- 4. reports, banned_users, broadcasts - only admin can manage
DROP POLICY IF EXISTS "public all" ON reports;
CREATE POLICY "anyone can report" ON reports FOR INSERT WITH CHECK (true);
CREATE POLICY "only admin can manage reports" ON reports FOR ALL USING (
  auth.jwt() ->> 'email' = 'etimvincentz001@gmail.com'
);

DROP POLICY IF EXISTS "public all" ON banned_users;
CREATE POLICY "only admin can manage banned" ON banned_users FOR ALL USING (
  auth.jwt() ->> 'email' = 'etimvincentz001@gmail.com'
);

DROP POLICY IF EXISTS "public all" ON broadcasts;
CREATE POLICY "public can read broadcasts" ON broadcasts FOR SELECT USING (true);
CREATE POLICY "only admin can manage broadcasts" ON broadcasts FOR ALL USING (
  auth.jwt() ->> 'email' = 'etimvincentz001@gmail.com'
);

-- Enable RLS
ALTER TABLE admin_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE banned_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE broadcasts ENABLE ROW LEVEL SECURITY;

-- CRITICAL: Delete secret key column - never store secret in table
ALTER TABLE admin_settings DROP COLUMN IF EXISTS paystack_secret_key;

-- Verify
SELECT 'RLS Secured for etimvincentz001@gmail.com - ONLY YOU' as status;
